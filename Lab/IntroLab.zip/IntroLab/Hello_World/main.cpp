/*
 * Author:     Gabriel Vasquez
 * Date:       Sept 6, 2021
 * Class:      CIS-17A-48593
 * Assignment: LabInto - "Hello World"
 */
#include <iostream>
using namespace std;

int main() {
    cout << "Hello World :)" << endl;
    return 0;
}

